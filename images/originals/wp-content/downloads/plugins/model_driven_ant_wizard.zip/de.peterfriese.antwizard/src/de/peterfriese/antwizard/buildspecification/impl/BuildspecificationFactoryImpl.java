/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package de.peterfriese.antwizard.buildspecification.impl;

import de.peterfriese.antwizard.buildspecification.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class BuildspecificationFactoryImpl extends EFactoryImpl implements BuildspecificationFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static BuildspecificationFactory init() {
		try {
			BuildspecificationFactory theBuildspecificationFactory = (BuildspecificationFactory)EPackage.Registry.INSTANCE.getEFactory("http://www.sample.org/buildspecification"); 
			if (theBuildspecificationFactory != null) {
				return theBuildspecificationFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new BuildspecificationFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BuildspecificationFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case BuildspecificationPackage.BUILD_SPECIFICATION: return createBuildSpecification();
			case BuildspecificationPackage.PROJECT: return createProject();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BuildSpecification createBuildSpecification() {
		BuildSpecificationImpl buildSpecification = new BuildSpecificationImpl();
		return buildSpecification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Project createProject() {
		ProjectImpl project = new ProjectImpl();
		return project;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BuildspecificationPackage getBuildspecificationPackage() {
		return (BuildspecificationPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static BuildspecificationPackage getPackage() {
		return BuildspecificationPackage.eINSTANCE;
	}

} //BuildspecificationFactoryImpl
