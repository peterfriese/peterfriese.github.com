/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package de.peterfriese.antwizard.buildspecification;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see de.peterfriese.antwizard.buildspecification.BuildspecificationFactory
 * @model kind="package"
 * @generated
 */
public interface BuildspecificationPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "buildspecification";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.sample.org/buildspecification";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "buildspecification";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	BuildspecificationPackage eINSTANCE = de.peterfriese.antwizard.buildspecification.impl.BuildspecificationPackageImpl.init();

	/**
	 * The meta object id for the '{@link de.peterfriese.antwizard.buildspecification.impl.BuildSpecificationImpl <em>Build Specification</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.peterfriese.antwizard.buildspecification.impl.BuildSpecificationImpl
	 * @see de.peterfriese.antwizard.buildspecification.impl.BuildspecificationPackageImpl#getBuildSpecification()
	 * @generated
	 */
	int BUILD_SPECIFICATION = 0;

	/**
	 * The feature id for the '<em><b>Project</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILD_SPECIFICATION__PROJECT = 0;

	/**
	 * The number of structural features of the '<em>Build Specification</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILD_SPECIFICATION_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link de.peterfriese.antwizard.buildspecification.impl.ProjectImpl <em>Project</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see de.peterfriese.antwizard.buildspecification.impl.ProjectImpl
	 * @see de.peterfriese.antwizard.buildspecification.impl.BuildspecificationPackageImpl#getProject()
	 * @generated
	 */
	int PROJECT = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROJECT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Source Folder</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROJECT__SOURCE_FOLDER = 1;

	/**
	 * The feature id for the '<em><b>Binary Folder</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROJECT__BINARY_FOLDER = 2;

	/**
	 * The number of structural features of the '<em>Project</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROJECT_FEATURE_COUNT = 3;


	/**
	 * Returns the meta object for class '{@link de.peterfriese.antwizard.buildspecification.BuildSpecification <em>Build Specification</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Build Specification</em>'.
	 * @see de.peterfriese.antwizard.buildspecification.BuildSpecification
	 * @generated
	 */
	EClass getBuildSpecification();

	/**
	 * Returns the meta object for the containment reference '{@link de.peterfriese.antwizard.buildspecification.BuildSpecification#getProject <em>Project</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Project</em>'.
	 * @see de.peterfriese.antwizard.buildspecification.BuildSpecification#getProject()
	 * @see #getBuildSpecification()
	 * @generated
	 */
	EReference getBuildSpecification_Project();

	/**
	 * Returns the meta object for class '{@link de.peterfriese.antwizard.buildspecification.Project <em>Project</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Project</em>'.
	 * @see de.peterfriese.antwizard.buildspecification.Project
	 * @generated
	 */
	EClass getProject();

	/**
	 * Returns the meta object for the attribute '{@link de.peterfriese.antwizard.buildspecification.Project#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see de.peterfriese.antwizard.buildspecification.Project#getName()
	 * @see #getProject()
	 * @generated
	 */
	EAttribute getProject_Name();

	/**
	 * Returns the meta object for the attribute '{@link de.peterfriese.antwizard.buildspecification.Project#getSourceFolder <em>Source Folder</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Source Folder</em>'.
	 * @see de.peterfriese.antwizard.buildspecification.Project#getSourceFolder()
	 * @see #getProject()
	 * @generated
	 */
	EAttribute getProject_SourceFolder();

	/**
	 * Returns the meta object for the attribute '{@link de.peterfriese.antwizard.buildspecification.Project#getBinaryFolder <em>Binary Folder</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Binary Folder</em>'.
	 * @see de.peterfriese.antwizard.buildspecification.Project#getBinaryFolder()
	 * @see #getProject()
	 * @generated
	 */
	EAttribute getProject_BinaryFolder();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	BuildspecificationFactory getBuildspecificationFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link de.peterfriese.antwizard.buildspecification.impl.BuildSpecificationImpl <em>Build Specification</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.peterfriese.antwizard.buildspecification.impl.BuildSpecificationImpl
		 * @see de.peterfriese.antwizard.buildspecification.impl.BuildspecificationPackageImpl#getBuildSpecification()
		 * @generated
		 */
		EClass BUILD_SPECIFICATION = eINSTANCE.getBuildSpecification();

		/**
		 * The meta object literal for the '<em><b>Project</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUILD_SPECIFICATION__PROJECT = eINSTANCE.getBuildSpecification_Project();

		/**
		 * The meta object literal for the '{@link de.peterfriese.antwizard.buildspecification.impl.ProjectImpl <em>Project</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see de.peterfriese.antwizard.buildspecification.impl.ProjectImpl
		 * @see de.peterfriese.antwizard.buildspecification.impl.BuildspecificationPackageImpl#getProject()
		 * @generated
		 */
		EClass PROJECT = eINSTANCE.getProject();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROJECT__NAME = eINSTANCE.getProject_Name();

		/**
		 * The meta object literal for the '<em><b>Source Folder</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROJECT__SOURCE_FOLDER = eINSTANCE.getProject_SourceFolder();

		/**
		 * The meta object literal for the '<em><b>Binary Folder</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROJECT__BINARY_FOLDER = eINSTANCE.getProject_BinaryFolder();

	}

} //BuildspecificationPackage
