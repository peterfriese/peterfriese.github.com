/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package de.peterfriese.antwizard.buildspecification;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Project</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link de.peterfriese.antwizard.buildspecification.Project#getName <em>Name</em>}</li>
 *   <li>{@link de.peterfriese.antwizard.buildspecification.Project#getSourceFolder <em>Source Folder</em>}</li>
 *   <li>{@link de.peterfriese.antwizard.buildspecification.Project#getBinaryFolder <em>Binary Folder</em>}</li>
 * </ul>
 * </p>
 *
 * @see de.peterfriese.antwizard.buildspecification.BuildspecificationPackage#getProject()
 * @model
 * @generated
 */
public interface Project extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see de.peterfriese.antwizard.buildspecification.BuildspecificationPackage#getProject_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link de.peterfriese.antwizard.buildspecification.Project#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Source Folder</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source Folder</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source Folder</em>' attribute.
	 * @see #setSourceFolder(String)
	 * @see de.peterfriese.antwizard.buildspecification.BuildspecificationPackage#getProject_SourceFolder()
	 * @model
	 * @generated
	 */
	String getSourceFolder();

	/**
	 * Sets the value of the '{@link de.peterfriese.antwizard.buildspecification.Project#getSourceFolder <em>Source Folder</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source Folder</em>' attribute.
	 * @see #getSourceFolder()
	 * @generated
	 */
	void setSourceFolder(String value);

	/**
	 * Returns the value of the '<em><b>Binary Folder</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Binary Folder</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Binary Folder</em>' attribute.
	 * @see #setBinaryFolder(String)
	 * @see de.peterfriese.antwizard.buildspecification.BuildspecificationPackage#getProject_BinaryFolder()
	 * @model
	 * @generated
	 */
	String getBinaryFolder();

	/**
	 * Sets the value of the '{@link de.peterfriese.antwizard.buildspecification.Project#getBinaryFolder <em>Binary Folder</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Binary Folder</em>' attribute.
	 * @see #getBinaryFolder()
	 * @generated
	 */
	void setBinaryFolder(String value);

} // Project
