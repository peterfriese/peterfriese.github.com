/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package de.peterfriese.antwizard.buildspecification;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Build Specification</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link de.peterfriese.antwizard.buildspecification.BuildSpecification#getProject <em>Project</em>}</li>
 * </ul>
 * </p>
 *
 * @see de.peterfriese.antwizard.buildspecification.BuildspecificationPackage#getBuildSpecification()
 * @model
 * @generated
 */
public interface BuildSpecification extends EObject {
	/**
	 * Returns the value of the '<em><b>Project</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Project</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Project</em>' containment reference.
	 * @see #setProject(Project)
	 * @see de.peterfriese.antwizard.buildspecification.BuildspecificationPackage#getBuildSpecification_Project()
	 * @model containment="true"
	 * @generated
	 */
	Project getProject();

	/**
	 * Sets the value of the '{@link de.peterfriese.antwizard.buildspecification.BuildSpecification#getProject <em>Project</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Project</em>' containment reference.
	 * @see #getProject()
	 * @generated
	 */
	void setProject(Project value);

} // BuildSpecification
