/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package de.peterfriese.antwizard.buildspecification.impl;

import de.peterfriese.antwizard.buildspecification.BuildspecificationPackage;
import de.peterfriese.antwizard.buildspecification.Project;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Project</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link de.peterfriese.antwizard.buildspecification.impl.ProjectImpl#getName <em>Name</em>}</li>
 *   <li>{@link de.peterfriese.antwizard.buildspecification.impl.ProjectImpl#getSourceFolder <em>Source Folder</em>}</li>
 *   <li>{@link de.peterfriese.antwizard.buildspecification.impl.ProjectImpl#getBinaryFolder <em>Binary Folder</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ProjectImpl extends EObjectImpl implements Project {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getSourceFolder() <em>Source Folder</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceFolder()
	 * @generated
	 * @ordered
	 */
	protected static final String SOURCE_FOLDER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSourceFolder() <em>Source Folder</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSourceFolder()
	 * @generated
	 * @ordered
	 */
	protected String sourceFolder = SOURCE_FOLDER_EDEFAULT;

	/**
	 * The default value of the '{@link #getBinaryFolder() <em>Binary Folder</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBinaryFolder()
	 * @generated
	 * @ordered
	 */
	protected static final String BINARY_FOLDER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBinaryFolder() <em>Binary Folder</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBinaryFolder()
	 * @generated
	 * @ordered
	 */
	protected String binaryFolder = BINARY_FOLDER_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProjectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BuildspecificationPackage.Literals.PROJECT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BuildspecificationPackage.PROJECT__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSourceFolder() {
		return sourceFolder;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSourceFolder(String newSourceFolder) {
		String oldSourceFolder = sourceFolder;
		sourceFolder = newSourceFolder;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BuildspecificationPackage.PROJECT__SOURCE_FOLDER, oldSourceFolder, sourceFolder));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBinaryFolder() {
		return binaryFolder;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBinaryFolder(String newBinaryFolder) {
		String oldBinaryFolder = binaryFolder;
		binaryFolder = newBinaryFolder;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BuildspecificationPackage.PROJECT__BINARY_FOLDER, oldBinaryFolder, binaryFolder));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case BuildspecificationPackage.PROJECT__NAME:
				return getName();
			case BuildspecificationPackage.PROJECT__SOURCE_FOLDER:
				return getSourceFolder();
			case BuildspecificationPackage.PROJECT__BINARY_FOLDER:
				return getBinaryFolder();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case BuildspecificationPackage.PROJECT__NAME:
				setName((String)newValue);
				return;
			case BuildspecificationPackage.PROJECT__SOURCE_FOLDER:
				setSourceFolder((String)newValue);
				return;
			case BuildspecificationPackage.PROJECT__BINARY_FOLDER:
				setBinaryFolder((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case BuildspecificationPackage.PROJECT__NAME:
				setName(NAME_EDEFAULT);
				return;
			case BuildspecificationPackage.PROJECT__SOURCE_FOLDER:
				setSourceFolder(SOURCE_FOLDER_EDEFAULT);
				return;
			case BuildspecificationPackage.PROJECT__BINARY_FOLDER:
				setBinaryFolder(BINARY_FOLDER_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case BuildspecificationPackage.PROJECT__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case BuildspecificationPackage.PROJECT__SOURCE_FOLDER:
				return SOURCE_FOLDER_EDEFAULT == null ? sourceFolder != null : !SOURCE_FOLDER_EDEFAULT.equals(sourceFolder);
			case BuildspecificationPackage.PROJECT__BINARY_FOLDER:
				return BINARY_FOLDER_EDEFAULT == null ? binaryFolder != null : !BINARY_FOLDER_EDEFAULT.equals(binaryFolder);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", sourceFolder: ");
		result.append(sourceFolder);
		result.append(", binaryFolder: ");
		result.append(binaryFolder);
		result.append(')');
		return result.toString();
	}

} //ProjectImpl
