package de.peterfriese.antwizard.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWizard;
import org.eclipse.xpand2.XpandExecutionContextImpl;
import org.eclipse.xpand2.XpandFacade;
import org.eclipse.xpand2.output.Outlet;
import org.eclipse.xpand2.output.OutputImpl;
import org.eclipse.xtend.typesystem.emf.EmfRegistryMetaModel;

import de.peterfriese.antwizard.buildspecification.BuildSpecification;
import de.peterfriese.antwizard.buildspecification.BuildspecificationFactory;
import de.peterfriese.antwizard.buildspecification.BuildspecificationPackage;
import de.peterfriese.antwizard.buildspecification.Project;

public class NewBuildFileFromExistingProject extends Wizard implements
		INewWizard {
	private NewBuildFileWizardPage page;
	private ISelection selection;

	/**
	 * Constructor for NewBuildFileFromExistingProject.
	 */
	public NewBuildFileFromExistingProject() {
		super();
		setNeedsProgressMonitor(true);
	}

	/**
	 * Adding the page to the wizard.
	 */

	public void addPages() {
		page = new NewBuildFileWizardPage(selection);
		addPage(page);
	}

	/**
	 * This method is called when 'Finish' button is pressed in the wizard. We
	 * will create an operation and run it using wizard as execution context.
	 */
	public boolean performFinish() {
		final String containerName = page.getContainerName();
		final String srcDirName = page.getSrcDirName();
		final String binDirName = page.getBinDirName();

		IRunnableWithProgress op = new IRunnableWithProgress() {
			public void run(IProgressMonitor monitor)
					throws InvocationTargetException {
				try {
					doFinish(containerName, srcDirName, binDirName, monitor);
				} catch (CoreException e) {
					throw new InvocationTargetException(e);
				} finally {
					monitor.done();
				}
			}
		};
		try {
			getContainer().run(true, false, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			Throwable realException = e.getTargetException();
			MessageDialog.openError(getShell(), "Error", realException
					.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * The worker method. It will find the container, create the file if missing
	 * or just replace its contents, and open the editor on the newly created
	 * file.
	 */
	private void doFinish(String containerName, String srcDirName,
			String binDirName, IProgressMonitor monitor) throws CoreException {
		monitor.beginTask("Running generator", 5);
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		IResource resource = root.findMember(new Path(containerName));

		IProject project = (IProject) resource.getAdapter(IProject.class);
		BuildSpecification buildSpecification = createModel(project,
				srcDirName, binDirName);
		generate(buildSpecification, monitor);
		monitor.worked(5);
	}

	private void generate(BuildSpecification buildSpec, IProgressMonitor monitor)
			throws CoreException {

		// get project root folder as absolute file system path
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		IResource resource = root.findMember(new Path(buildSpec.getProject()
				.getName()));
		String containerName = resource.getLocation().toPortableString();

		// configure outlets
		OutputImpl output = new OutputImpl();
		Outlet outlet = new Outlet(containerName);
		outlet.setOverwrite(true);
		output.addOutlet(outlet);

		// create execution context
		Map globalVarsMap = new HashMap();
		XpandExecutionContextImpl execCtx = new XpandExecutionContextImpl(
				output, null, globalVarsMap, null, null);
		EmfRegistryMetaModel metamodel = new EmfRegistryMetaModel() {
			@Override
			protected EPackage[] allPackages() {
				return new EPackage[] { BuildspecificationPackage.eINSTANCE,
						EcorePackage.eINSTANCE };
			}
		};
		execCtx.registerMetaModel(metamodel);

		// generate
		XpandFacade facade = XpandFacade.create(execCtx);
		String templatePath = "template::BuildTemplate::main";
		facade.evaluate(templatePath, buildSpec);

		resource.refreshLocal(IResource.DEPTH_INFINITE, monitor);
	}

	private BuildSpecification createModel(IProject project, String srcDirName,
			String binDirName) {
		BuildSpecification buildSpecification = BuildspecificationFactory.eINSTANCE
				.createBuildSpecification();
		Project projectSpecification = BuildspecificationFactory.eINSTANCE
				.createProject();
		projectSpecification.setName(project.getName());
		projectSpecification.setBinaryFolder(binDirName);
		projectSpecification.setSourceFolder(srcDirName);

		buildSpecification.setProject(projectSpecification);
		return buildSpecification;
	}

	/**
	 * We will accept the selection in the workbench to see if we can initialize
	 * from it.
	 * 
	 * @see IWorkbenchWizard#init(IWorkbench, IStructuredSelection)
	 */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
	}
}