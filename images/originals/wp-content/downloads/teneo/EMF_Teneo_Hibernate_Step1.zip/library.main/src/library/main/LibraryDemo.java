package library.main;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.teneo.hibernate.HbDataStore;
import org.eclipse.emf.teneo.hibernate.HbHelper;
import org.eclipse.example.library.Book;
import org.eclipse.example.library.BookCategory;
import org.eclipse.example.library.Library;
import org.eclipse.example.library.LibraryFactory;
import org.eclipse.example.library.LibraryPackage;
import org.eclipse.example.library.Writer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class LibraryDemo {

	public static void main(String[] args) {
		// create the data store
		String dataStoreName = "LibraryDataStore";
		HbDataStore dataStore = HbHelper.INSTANCE
				.createRegisterDataStore(dataStoreName);

		// register the model package with the data store
		dataStore.setEPackages(new EPackage[] { LibraryPackage.eINSTANCE });

		// initialize the data store, which creates the tables
		dataStore.initialize();

		SessionFactory sessionFactory = dataStore.getSessionFactory();
		{
			Session session = sessionFactory.openSession();
			session.beginTransaction();

			// create a library
			Library library = LibraryFactory.eINSTANCE.createLibrary();
			library.setName("Developer's bookshelf");

			// store the library
			session.save(library);

			// create an author
			Writer writer = LibraryFactory.eINSTANCE.createWriter();
			writer.setName("A. K. Dewdney");

			// create a book
			Book book = LibraryFactory.eINSTANCE.createBook();
			book.setTitle("The New Turing Omnibus");
			book.setPages(480);
			book.setCategory(BookCategory.MYSTERY); // oh well, let's hope it's
													// not mystery to most
													// readers!
			book.setAuthor(writer);

			// add book and writer to library
			library.getBooks().add(book);
			library.getWriters().add(writer);

			// commit changes to the database and close the session
			session.getTransaction().commit();
			session.close();
		}
	}

}
