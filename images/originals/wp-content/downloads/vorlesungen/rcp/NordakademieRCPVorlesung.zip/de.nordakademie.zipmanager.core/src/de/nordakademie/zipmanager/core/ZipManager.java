/*
 * ZipManager.java created on 15.06.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */
package de.nordakademie.zipmanager.core;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.collections.Closure;
import org.apache.commons.collections.CollectionUtils;

import de.nordakademie.zipmanager.core.listener.IZipManagerListener;

/**
 * @author Stefan Reichert
 */
public class ZipManager {

	/**
	 * Unzips the given file to the given traget directory.
	 * 
	 * @param zipFile
	 *        The <i>ZIP file</i> to be unziped
	 * @param targetDirectory
	 *        The target directory
	 */
	public static final void unzip(ZipFile zipFile, File targetDirectory) {
		new ZipManager(zipFile).unzip(targetDirectory);
	}

	/** The <code>List</code> of <code>IZipManagerListener</code>s. */
	private List listeners;

	/** The <i>ZIP file</i> to be unziped. */
	private final ZipFile zipFile;

	/**
	 * Constructor for ZipManager.
	 * 
	 * @param zipFile
	 *        The <i>ZIP file</i> to be unziped
	 */
	public ZipManager(ZipFile zipFile) {
		super();
		this.zipFile = zipFile;
		this.listeners = new ArrayList();
	}

	/**
	 * Unzips the <i>ZIP file</i> to the given target directory.
	 * 
	 * @param targetDirectory
	 *        The target directory
	 */
	public void unzip(File targetDirectory) {
		Enumeration zipFileEntries = zipFile.entries();
		while (zipFileEntries.hasMoreElements()) {
			// Get the first entry
			ZipEntry zipEntry = (ZipEntry) zipFileEntries.nextElement();
			publishExtractionStart(zipEntry);
			try {
				// Open the output file
				if (!zipEntry.isDirectory()) {
					File zipFileEntryFile = new File(targetDirectory.getPath(),
							zipEntry.toString());
					zipFileEntryFile.getParentFile().mkdirs();
					BufferedOutputStream zipFileEntryOutputStream = new BufferedOutputStream(
							new FileOutputStream(zipFileEntryFile));
					InputStream zipFileEntryInputStream = zipFile
							.getInputStream(zipEntry);

					// Transfer bytes from the ZIP file to the output
					// file
					byte[] buffer = new byte[1024];
					int length;
					while ((length = zipFileEntryInputStream.read(buffer)) > 0) {
						zipFileEntryOutputStream.write(buffer, 0, length);
					}

					// Close the streams
					zipFileEntryOutputStream.flush();
					zipFileEntryOutputStream.close();
					zipFileEntryInputStream.close();
				}
				publishExtractionFinish(zipEntry);
			}
			catch (IOException exception) {
				publishExtractionAbort(zipEntry, exception);
			}
		}
	}

	/**
	 * Adds a <code>IZipManagerListener</code> to the <code>List</code> of
	 * listeners.
	 * 
	 * @param listener
	 *        The <code>IZipManagerListener</code> to add
	 */
	public void addListener(IZipManagerListener listener) {
		this.listeners.add(listener);
	}

	/**
	 * Removes a <code>IZipManagerListener</code> from the <code>List</code>
	 * of listeners.
	 * 
	 * @param listener
	 *        The <code>IZipManagerListener</code> to add
	 */
	public void removeListener(IZipManagerListener listener) {
		this.listeners.remove(listener);
	}

	/**
	 * Publishes a starting extraction of a <code>ZipEntry</code>.
	 * 
	 * @param zipEntry
	 *        The <code>ZipEntry</code> which is started to be extracted
	 */
	private void publishExtractionStart(final ZipEntry zipEntry) {
		CollectionUtils.forAllDo(new ArrayList(listeners), new Closure() {
			/**
			 * @see org.apache.commons.collections.Closure#execute(java.lang.Object)
			 */
			public void execute(Object object) {
				IZipManagerListener listener = (IZipManagerListener) object;
				listener.extractionStarted(zipEntry);
			}
		});
	}

	/**
	 * Publishes a finishe extraction of a <code>ZipEntry</code>.
	 * 
	 * @param zipEntry
	 *        The <code>ZipEntry</code> which is finished to be extracted
	 */
	private void publishExtractionFinish(final ZipEntry zipEntry) {
		CollectionUtils.forAllDo(new ArrayList(listeners), new Closure() {
			/**
			 * @see org.apache.commons.collections.Closure#execute(java.lang.Object)
			 */
			public void execute(Object object) {
				IZipManagerListener listener = (IZipManagerListener) object;
				listener.extractionFinished(zipEntry);
			}
		});
	}

	/**
	 * Publishes aa aborted extraction of a <code>ZipEntry</code>.
	 * 
	 * @param zipEntry
	 *        The <code>ZipEntry</code> which is started to be extracted
	 * @param throwable
	 *        The <code>Throwable</code> which caused the abortion of the
	 *        extraction or null if not available
	 */
	private void publishExtractionAbort(final ZipEntry zipEntry,
			final Throwable throwable) {
		CollectionUtils.forAllDo(new ArrayList(listeners), new Closure() {
			/**
			 * @see org.apache.commons.collections.Closure#execute(java.lang.Object)
			 */
			public void execute(Object object) {
				IZipManagerListener listener = (IZipManagerListener) object;
				listener.extractionAborted(zipEntry, throwable);
			}
		});
	}
}
