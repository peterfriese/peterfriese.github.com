/*
 * IZipManagerListener.java created on 15.06.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */
package de.nordakademie.zipmanager.core.listener;

import java.util.zip.ZipEntry;

/**
 * @author Stefan Reichert
 */
public interface IZipManagerListener {

	/**
	 * Invoked when the extraction of the given <code>ZipEntry</code> started.
	 * 
	 * @param zipEntry
	 *        The <code>ZipEntry</code> which is started to be extracted
	 */
	void extractionStarted(ZipEntry entry);

	/**
	 * Invoked when the extraction of the given <code>ZipEntry</code> started. *
	 * 
	 * @param zipEntry
	 *        The <code>ZipEntry</code> which is finished to be extracted
	 */
	void extractionFinished(ZipEntry entry);

	/**
	 * Invoked when the extraction of the given <code>ZipEntry</code> started.
	 * 
	 * @param zipEntry
	 *        The <code>ZipEntry</code> which was aborted to be extracted
	 * @param throwable
	 *        The <code>Throwable</code> which caused the abortion of the
	 *        extraction or null if not available
	 */
	void extractionAborted(ZipEntry entry, Throwable throwable);
}
