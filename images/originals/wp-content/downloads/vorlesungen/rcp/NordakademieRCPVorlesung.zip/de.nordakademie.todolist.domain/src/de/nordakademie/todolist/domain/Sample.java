/*
 * Sample.java created on 08.08.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */
package de.nordakademie.todolist.domain;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;

/**
 * This sample shows how to read and write todo list files with XMLBeans.
 * 
 * @author Peter Friese
 */
public class Sample {

	private static final String XML_NAMESPACE_TODOLIST = "http://www.nordakademie.de/todolist/domain";

	private static XmlOptions namespaceXmlOptions;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		setupDefaultNamespaces();
		File todolistFile = new File("C:\temp\todo.list");
		createDocument(todolistFile);
		readDocument(todolistFile);
	}

	public static void createDocument(File todolistFile) {
		TodolistDocument document = TodolistDocument.Factory.newInstance();
		Item root = document.addNewTodolist();
		root.setName("Todo list");
		root.setDescription("Was so zu tun ist.");

		Item itemEinkaufen = root.addNewItem();
		itemEinkaufen.setName("Einkaufen");
		itemEinkaufen.setDescription("Die Wochenendeeink�ufe erledigen");

		Item item = itemEinkaufen.addNewItem();
		item.setName("Kaffee");

		Item item2 = itemEinkaufen.addNewItem();
		item2.setName("Milch");

		Item item3 = itemEinkaufen.addNewItem();
		item3.setName("M�sli");

		Item itemWohnungPutzen = root.addNewItem();
		itemWohnungPutzen.setName("Wohnung putzen");
		itemWohnungPutzen
				.setDescription("Die Wohnung reinigen, damit es sch�n sauber wird");

		try {
			document.save(todolistFile, namespaceXmlOptions);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void readDocument(File todolistFile) {
		try {
			TodolistDocument document = TodolistDocument.Factory.parse(
					todolistFile, namespaceXmlOptions);
			Item root = document.getTodolist();
			walkItem(root);
		}
		catch (XmlException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void walkItem(Item item) {
		printItem(item);
		Item[] items = item.getItemArray();
		for (int i = 0; i < items.length; i++) {
			Item item2 = items[i];
			walkItem(item2);
		}
	}

	private static void printItem(Item item2) {
		System.out.println("Item " + item2.getName() + ": "
				+ item2.getDescription());
	}

	/**
	 * Setup an XmlOptions instance so the parser will assume the default
	 * namespace for the config documents even if it has no namespace set.
	 */
	public static void setupDefaultNamespaces() {
		namespaceXmlOptions = new XmlOptions();
		Map namespaceMapping = new HashMap();
		namespaceMapping.put("", XML_NAMESPACE_TODOLIST);
		namespaceXmlOptions.setLoadSubstituteNamespaces(namespaceMapping);
		namespaceXmlOptions.setUseDefaultNamespace();
		namespaceXmlOptions.setSavePrettyPrint().setSavePrettyPrintIndent(4);
	}

}
