/*
 * SWIAView.java created on 30.07.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */
package de.nordakademie.swia.ui.view;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

/**
 * @author Peter Friese
 */
public class SWIAView extends ViewPart {

	private Composite top = null;

	private Text text = null;

	private Button button = null;

	private Label label = null;

	private Text text1 = null;

	/**
	 * 
	 */
	public SWIAView() {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.part.WorkbenchPart#createPartControl(org.eclipse.swt.widgets.Composite)
	 */
	public void createPartControl(Composite parent) {
		GridData gridData2 = new GridData();
		gridData2.grabExcessHorizontalSpace = true;
		gridData2.verticalAlignment = GridData.FILL;
		gridData2.horizontalSpan = 2;
		gridData2.verticalSpan = 2;
		gridData2.grabExcessVerticalSpace = true;
		gridData2.horizontalAlignment = GridData.FILL;
		GridData gridData11 = new GridData();
		gridData11.grabExcessHorizontalSpace = true;
		gridData11.verticalAlignment = GridData.CENTER;
		gridData11.horizontalSpan = 2;
		gridData11.horizontalAlignment = GridData.FILL;
		GridData gridData1 = new GridData();
		gridData1.grabExcessHorizontalSpace = false;
		gridData1.verticalAlignment = GridData.CENTER;
		gridData1.heightHint = -1;
		gridData1.widthHint = 75;
		gridData1.horizontalAlignment = GridData.BEGINNING;
		GridData gridData = new GridData();
		gridData.horizontalAlignment = GridData.FILL;
		gridData.grabExcessHorizontalSpace = true;
		gridData.verticalAlignment = GridData.CENTER;
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 2;
		gridLayout.makeColumnsEqualWidth = false;
		top = new Composite(parent, SWT.NONE);
		top.setLayout(gridLayout);
		text = new Text(top, SWT.BORDER);
		text.setLayoutData(gridData);
		button = new Button(top, SWT.NONE);
		button.setText("Say Hi!");
		button.setLayoutData(gridData1);
		label = new Label(top, SWT.NONE);
		label.setText("Label");
		label.setVisible(false);
		label.setLayoutData(gridData11);
		text1 = new Text(top, SWT.BORDER | SWT.MULTI);
		text1.setLayoutData(gridData2);
		button
				.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() {
					public void widgetSelected(
							org.eclipse.swt.events.SelectionEvent e) {
						String yourName = text.getText();
						System.out.println("Hello, " + yourName);
						label.setText("Hello, " + yourName);
						label.setVisible(true);
					}
				});
		button
				.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() {
					public void widgetSelected(
							org.eclipse.swt.events.SelectionEvent e) {
						String yourName = text.getText();
						System.out.println("Hello again, " + yourName);
						text1.setText("Hello again, " + yourName + "\n"
								+ text1.getText());
					}
				});
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.part.WorkbenchPart#setFocus()
	 */
	public void setFocus() {

	}

}
