/*
 * ItemDao.java created on 17.07.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */

package de.nordakademie.todolist.core;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;

import de.nordakademie.todolist.domain.Item;
import de.nordakademie.todolist.domain.TodolistDocument;

/**
 * @author Stefan Reichert
 * @author Peter Friese
 */
public class ItemDao {

	private static final String XML_NAMESPACE_TODOLIST = "http://www.nordakademie.de/todolist/domain";

	private static XmlOptions namespaceXmlOptions;

	/**
	 * Reads the <code>List</code> of root <code>Item</code>s from the
	 * disc.
	 * 
	 * @return the <code>List</code> of root <code>Items</code>
	 */
	public List readRootItems(File todolistFile) {
		setupDefaultNamespaces();
		try {
			TodolistDocument document = TodolistDocument.Factory.parse(
					todolistFile, namespaceXmlOptions);
			Item root = document.getTodolist();
			Item[] itemArray = root.getItemArray();
			return new ArrayList(Arrays.asList(itemArray));
		}
		catch (XmlException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return new ArrayList();

	}

	/**
	 * Saves the <code>List</code> of root <code>Items</code> to disc.
	 */
	public void writeRootItems(List items, File todolistFile) {
		setupDefaultNamespaces();
		TodolistDocument document = TodolistDocument.Factory.newInstance(namespaceXmlOptions);
		Item root = document.addNewTodolist();
		root.setItemArray((Item[]) items.toArray(new Item[items.size()]));
		try {
			document.save(todolistFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Setup an XmlOptions instance so the parser will assume the default
	 * namespace for the config documents even if it has no namespace set.
	 */
	private static void setupDefaultNamespaces() {
		namespaceXmlOptions = new XmlOptions();
		Map namespaceMapping = new HashMap();
		namespaceMapping.put("", XML_NAMESPACE_TODOLIST);
		namespaceXmlOptions.setLoadSubstituteNamespaces(namespaceMapping);
		namespaceXmlOptions.setUseDefaultNamespace();
		namespaceXmlOptions.setSavePrettyPrint().setSavePrettyPrintIndent(4);
	}
}
