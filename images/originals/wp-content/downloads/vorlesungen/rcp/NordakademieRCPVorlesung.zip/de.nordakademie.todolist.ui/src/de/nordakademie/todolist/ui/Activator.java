package de.nordakademie.todolist.ui;

import java.io.File;
import java.util.List;

import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

import de.nordakademie.todolist.core.ItemDao;
import de.nordakademie.todolist.domain.Sample;

/**
 * The activator class controls the plug-in life cycle
 */
public class Activator extends AbstractUIPlugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "de.nordakademie.todolist.ui";

	// The shared instance
	private static Activator plugin;

	// The List of todos
	private List todolist;

	/**
	 * The constructor
	 */
	public Activator() {
		plugin = this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
		// Load the todolist
		StringBuffer todolistFilename = new StringBuffer();
		todolistFilename.append(getStateLocation().toOSString());
		todolistFilename.append(File.separator);
		todolistFilename.append("todolist.xml");
		File todolistFile = new File(todolistFilename.toString());
		if (!todolistFile.exists()) {
			Sample.setupDefaultNamespaces();
			Sample.createDocument(todolistFile);
			Sample.readDocument(todolistFile);
		}
		todolist = new ItemDao().readRootItems(todolistFile);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		StringBuffer todolistFilename = new StringBuffer();
		todolistFilename.append(getBundle().getLocation());
		todolistFilename.append(File.separator);
		todolistFilename.append("todolist.xml");
		File todolistFile = new File(todolistFilename.toString());
		new ItemDao().writeRootItems(todolist, todolistFile);
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 * 
	 * @return the shared instance
	 */
	public static Activator getDefault() {
		return plugin;
	}

	public List getTodolist() {
		return todolist;
	}

}
