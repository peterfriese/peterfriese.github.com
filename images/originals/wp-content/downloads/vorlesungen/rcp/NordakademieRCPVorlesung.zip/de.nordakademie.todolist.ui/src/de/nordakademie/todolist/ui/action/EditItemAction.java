/*
 * EditItemAction.java created on 23.08.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */

package de.nordakademie.todolist.ui.action;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IPropertyListener;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.PartInitException;

import de.nordakademie.todolist.domain.Item;
import de.nordakademie.todolist.ui.editor.ItemEditor;
import de.nordakademie.todolist.ui.editor.ItemEditorInput;
import de.nordakademie.todolist.ui.view.TodoView;

/**
 * @author Stefan Reichert
 */
public class EditItemAction implements IViewActionDelegate {

	private Item item;

	private TodoView view;

	/**
	 * @see org.eclipse.ui.IViewActionDelegate#init(org.eclipse.ui.IViewPart)
	 */
	public void init(IViewPart view) {
		this.view = (TodoView) view;
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
	 */
	public void run(IAction action) {
		if (item != null) {
			try {
				IEditorPart editorPart = view.getSite().getPage().openEditor(
						new ItemEditorInput(item), ItemEditor.ID);
				editorPart.addPropertyListener(new IPropertyListener() {
					/**
					 * @see org.eclipse.ui.IPropertyListener#propertyChanged(java.lang.Object,
					 *      int)
					 */
					public void propertyChanged(Object source, int propId) {
						if (propId == ItemEditor.PROP_TODOLIST_CHANGED) {
							view.refresh();
						}
					}
				});
			}
			catch (PartInitException exception) {
				exception.printStackTrace();
			}
		}
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(org.eclipse.jface.action.IAction,
	 *      org.eclipse.jface.viewers.ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (!structuredSelection.isEmpty()) {
			item = (Item) structuredSelection.getFirstElement();
		}
	}

}
