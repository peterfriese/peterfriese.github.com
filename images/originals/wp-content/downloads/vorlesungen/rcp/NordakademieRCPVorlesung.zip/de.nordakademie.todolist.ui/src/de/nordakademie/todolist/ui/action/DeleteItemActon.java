/*
 * DeleteItemActon.java created on 29.08.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */

package de.nordakademie.todolist.ui.action;

import java.util.Arrays;
import java.util.List;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

import de.nordakademie.todolist.domain.Item;
import de.nordakademie.todolist.ui.Activator;
import de.nordakademie.todolist.ui.view.TodoView;

/**
 * @author Stefan Reichert
 */
public class DeleteItemActon implements IViewActionDelegate {

	private Item item;

	private TodoView todoView;

	/**
	 * @see org.eclipse.ui.IViewActionDelegate#init(org.eclipse.ui.IViewPart)
	 */
	public void init(IViewPart view) {
		todoView = (TodoView) view;
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
	 */
	public void run(IAction action) {
		if (item != null) {
			Item parent = findParent(item, Activator.getDefault().getTodolist());
			if (parent == null) {
				Activator.getDefault().getTodolist().remove(item);
			}
			else {
				List children = Arrays.asList(parent.getItemArray());
				parent.removeItem(children.indexOf(item));
			}
			todoView.refresh();
		}

	}

	/**
	 * Finds the parent of the given Item recursively.
	 */
	private Item findParent(Item item, List items) {
		if (!items.isEmpty()) {
			for (int index = 0; index < items.size(); index++) {
				Item indexedItem = (Item) items.get(index);
				List children = Arrays.asList(indexedItem.getItemArray());
				if (children.contains(item)) {
					return indexedItem;
				}
				else {
					Item parent = findParent(item, children);
					if (parent != null) {
						return parent;
					}
				}
			}
		}
		return null;
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(org.eclipse.jface.action.IAction,
	 *      org.eclipse.jface.viewers.ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (!structuredSelection.isEmpty()) {
			item = (Item) structuredSelection.getFirstElement();
		}
	}

}
