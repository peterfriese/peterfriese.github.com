/*
 * TodoView.java created on 14.08.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */
package de.nordakademie.todolist.ui.view;

import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.part.ViewPart;

import de.nordakademie.todolist.ui.Activator;

/**
 * @author Peter Friese
 */
public class TodoView extends ViewPart {

	public static final String ID = "de.nordakademie.todolist.ui.view.TodoView"; // TODO

	// Needs
	// to
	// be
	// whatever
	// is
	// mentioned
	// in
	// plugin.xml

	private Composite top = null;

	private Tree treeTodoItems = null;

	private TreeViewer treeViewer = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.part.WorkbenchPart#createPartControl(org.eclipse.swt.widgets.Composite)
	 */
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub
		GridData gridData = new GridData();
		gridData.grabExcessHorizontalSpace = true;
		gridData.horizontalAlignment = GridData.FILL;
		gridData.verticalAlignment = GridData.FILL;
		gridData.grabExcessVerticalSpace = true;
		top = new Composite(parent, SWT.NONE);
		top.setLayout(new GridLayout());
		treeTodoItems = new Tree(top, SWT.BORDER | SWT.FULL_SELECTION);
		treeTodoItems.setHeaderVisible(true);
		treeTodoItems.setLayoutData(gridData);
		treeTodoItems.setLinesVisible(true);
		treeViewer = new TreeViewer(treeTodoItems);
		TreeColumn treeColumn = new TreeColumn(treeTodoItems, SWT.NONE);
		treeColumn.setWidth(120);
		treeColumn.setText("Todo");
		TreeColumn treeColumn1 = new TreeColumn(treeTodoItems, SWT.LEFT);
		treeColumn1.setWidth(200);
		treeColumn1.setText("Beschreibung");

		treeViewer.setContentProvider(new TodoListContentProvider());
		treeViewer.setLabelProvider(new TodoListLabelProvider());
		treeViewer.setInput(Activator.getDefault().getTodolist());
		treeViewer.setSorter(new ViewerSorter());

		initializeContextMenu();
		initializeToolbar();
		initializeMenuBar();
	}

	private void initializeMenuBar() {
		IMenuManager menuBarManager = getViewSite().getActionBars()
				.getMenuManager();
		menuBarManager.add(new Separator("create"));
		menuBarManager.add(new Separator("edit"));
		menuBarManager.add(new GroupMarker("delete"));
		menuBarManager.add(new GroupMarker(
				IWorkbenchActionConstants.MB_ADDITIONS));
		getViewSite().getActionBars().updateActionBars();
	}

	private void initializeToolbar() {
		IToolBarManager toolBarManager = getViewSite().getActionBars()
				.getToolBarManager();
		toolBarManager.add(new Separator("create"));
		toolBarManager.add(new Separator("edit"));
		toolBarManager.add(new GroupMarker("delete"));
		toolBarManager.add(new GroupMarker(
				IWorkbenchActionConstants.MB_ADDITIONS));
		getViewSite().getActionBars().updateActionBars();
	}

	private void initializeContextMenu() {
		MenuManager menuManager = new MenuManager();
		menuManager.add(new Separator("create"));
		menuManager.add(new Separator("edit"));
		menuManager.add(new GroupMarker("delete"));
		menuManager
				.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
		getViewSite().registerContextMenu("de.nordakademie.todolist.menu",
				menuManager, treeViewer);
		Menu menu = menuManager.createContextMenu(treeViewer.getTree());
		treeViewer.getTree().setMenu(menu);
	}

	public void refresh() {
		Object[] expandedElements = treeViewer.getExpandedElements();
		ISelection selection = treeViewer.getSelection();
		treeViewer.setInput(Activator.getDefault().getTodolist());
		treeViewer.setExpandedElements(expandedElements);
		treeViewer.setSelection(selection);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.part.WorkbenchPart#setFocus()
	 */
	public void setFocus() {
		// TODO Auto-generated method stub

	}

} // @jve:decl-index=0:visual-constraint="10,10,642,343"
