/*
 * DeleteItemActon.java created on 29.08.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */

package de.nordakademie.todolist.ui.action;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

import de.nordakademie.todolist.domain.Item;
import de.nordakademie.todolist.ui.view.TodoView;

/**
 * @author Stefan Reichert
 */
public class CreateChildItemActon implements IViewActionDelegate {

	private Item parent;

	private TodoView todoView;

	/**
	 * @see org.eclipse.ui.IViewActionDelegate#init(org.eclipse.ui.IViewPart)
	 */
	public void init(IViewPart view) {
		todoView = (TodoView) view;
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
	 */
	public void run(IAction action) {
		if (parent != null) {
			InputDialog inputDialog = new InputDialog(todoView.getSite()
					.getShell(), "Create Child-Item for " + parent.getName(),
					"Please enter the name of the Item", new String(), null);
			if (inputDialog.open() == Dialog.OK) {
				Item item = parent.addNewItem();
				item.setName(inputDialog.getValue());
				item.setDescription(new String());
				todoView.refresh();
			}
		}

	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(org.eclipse.jface.action.IAction,
	 *      org.eclipse.jface.viewers.ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
		IStructuredSelection structuredSelection = (IStructuredSelection) selection;
		if (!structuredSelection.isEmpty()) {
			parent = (Item) structuredSelection.getFirstElement();
		}
	}

}
