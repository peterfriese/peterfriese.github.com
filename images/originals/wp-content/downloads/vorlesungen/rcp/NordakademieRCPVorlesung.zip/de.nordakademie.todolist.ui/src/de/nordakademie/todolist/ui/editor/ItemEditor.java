/*
 * ItemEditor.java created on 23.08.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */

package de.nordakademie.todolist.ui.editor;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.part.EditorPart;

/**
 * @author Stefan Reichert
 */
public class ItemEditor extends EditorPart {

	public static final String ID = "de.nordakademie.todolist.ui.editor.ItemEditor"; // TODO

	public static final int PROP_TODOLIST_CHANGED = 42;

	// Needs
	// to
	// be
	// whatever
	// is
	// mentioned
	// in
	// plugin.xml

	private Composite top = null;

	private FormToolkit formToolkit = null; // @jve:decl-index=0:visual-constraint=""

	private ScrolledForm scrolledForm = null;

	private Text textName = null;

	private Text textDescription = null;

	protected boolean dirty;

	/**
	 * @see org.eclipse.ui.part.EditorPart#doSave(org.eclipse.core.runtime.IProgressMonitor)
	 */
	public void doSave(IProgressMonitor monitor) {
		monitor.beginTask("Speichern des Items", 100);
		ItemEditorInput itemEditorInput = (ItemEditorInput) getEditorInput();
		monitor.worked(20);
		itemEditorInput.getItem().setName(textName.getText());
		itemEditorInput.getItem().setDescription(textDescription.getText());
		monitor.worked(80);
		monitor.done();
		dirty = false;
		firePropertyChange(PROP_DIRTY);
		firePropertyChange(PROP_TODOLIST_CHANGED);
	}

	/**
	 * @see org.eclipse.ui.part.EditorPart#doSaveAs()
	 */
	public void doSaveAs() {
	}

	/**
	 * @see org.eclipse.ui.part.EditorPart#init(org.eclipse.ui.IEditorSite,
	 *      org.eclipse.ui.IEditorInput)
	 */
	public void init(IEditorSite site, IEditorInput input)
			throws PartInitException {
		setSite(site);
		setInput(input);
	}

	/**
	 * @see org.eclipse.ui.part.EditorPart#isDirty()
	 */
	public boolean isDirty() {
		// TODO Auto-generated method stub
		return dirty;
	}

	/**
	 * @see org.eclipse.ui.part.EditorPart#isSaveAsAllowed()
	 */
	public boolean isSaveAsAllowed() {
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @see org.eclipse.ui.part.WorkbenchPart#createPartControl(org.eclipse.swt.widgets.Composite)
	 */
	public void createPartControl(Composite parent) {
		GridLayout gridLayout = new GridLayout();
		gridLayout.horizontalSpacing = 0;
		gridLayout.marginWidth = 0;
		gridLayout.marginHeight = 0;
		gridLayout.verticalSpacing = 0;
		top = new Composite(parent, SWT.NONE);
		createScrolledForm();
		top.setLayout(gridLayout);
	}

	/**
	 * @see org.eclipse.ui.part.WorkbenchPart#setFocus()
	 */
	public void setFocus() {
		// TODO Auto-generated method stub

	}

	/**
	 * This method initializes formToolkit
	 * 
	 * @return org.eclipse.ui.forms.widgets.FormToolkit
	 */
	private FormToolkit getFormToolkit() {
		if (formToolkit == null) {
			formToolkit = new FormToolkit(Display.getCurrent());
		}
		return formToolkit;
	}

	/**
	 * This method initializes scrolledForm
	 */
	private void createScrolledForm() {
		GridData gridData2 = new GridData();
		gridData2.grabExcessHorizontalSpace = true;
		gridData2.verticalAlignment = GridData.CENTER;
		gridData2.horizontalAlignment = GridData.FILL;
		GridData gridData1 = new GridData();
		gridData1.horizontalAlignment = GridData.FILL;
		gridData1.grabExcessHorizontalSpace = true;
		gridData1.verticalAlignment = GridData.CENTER;
		GridLayout gridLayout1 = new GridLayout();
		gridLayout1.numColumns = 2;
		GridData gridData = new GridData();
		gridData.horizontalAlignment = GridData.FILL;
		gridData.grabExcessHorizontalSpace = true;
		gridData.grabExcessVerticalSpace = true;
		gridData.verticalAlignment = GridData.FILL;
		scrolledForm = getFormToolkit().createScrolledForm(top);
		scrolledForm.setLayoutData(gridData);
		scrolledForm.getBody().setLayout(gridLayout1);
		getFormToolkit().createLabel(scrolledForm.getBody(), "Name:");
		textName = getFormToolkit().createText(scrolledForm.getBody(), null,
				SWT.SINGLE | SWT.BORDER);
		textName.setLayoutData(gridData1);
		textName.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dirty = true;
				firePropertyChange(PROP_DIRTY);
			}
		});
		getFormToolkit().createLabel(scrolledForm.getBody(), "Description:");
		textDescription = getFormToolkit().createText(scrolledForm.getBody(),
				null, SWT.SINGLE | SWT.BORDER);
		textDescription.setLayoutData(gridData2);
		textDescription.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dirty = true;
				firePropertyChange(PROP_DIRTY);
			}
		});

		// Set the Itemdata
		ItemEditorInput itemEditorInput = (ItemEditorInput) getEditorInput();

		String name = itemEditorInput.getItem().getName();
		if (name == null) {
			name = new String();
		}
		textName.setText(name);

		String description = itemEditorInput.getItem().getDescription();
		if (description == null) {
			description = new String();
		}
		textDescription.setText(description);
	}
}
