/*
 * TodoListLabelProvider.java created on 15.08.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */
package de.nordakademie.todolist.ui.view;

import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

import de.nordakademie.todolist.domain.Item;

/**
 * @author Peter Friese
 */
public class TodoListLabelProvider extends LabelProvider implements
		ITableLabelProvider {

	public Image getColumnImage(Object element, int columnIndex) {
		return null;
	}

	public String getColumnText(Object element, int columnIndex) {
		if (element instanceof Item) {
			Item todoItem = (Item) element;
			if (columnIndex == 0){
				return todoItem.getName();
			}
			else if (columnIndex == 1) {
				return todoItem.getDescription();
			}
		}
		return super.getText(element);
	}

}
