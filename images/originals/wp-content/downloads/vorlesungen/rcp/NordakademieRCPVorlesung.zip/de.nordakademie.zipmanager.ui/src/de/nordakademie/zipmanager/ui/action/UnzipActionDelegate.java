/*
 * UnzipActionDelegate.java created on 15.06.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */
package de.nordakademie.zipmanager.ui.action;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.jobs.IJobChangeEvent;
import org.eclipse.core.runtime.jobs.JobChangeAdapter;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;

import de.nordakademie.zipmanager.ui.dialog.UnzipTitleAreaDialog;
import de.nordakademie.zipmanager.ui.job.UnzipJob;

/**
 * @author Stefan Reichert
 */
public class UnzipActionDelegate implements IWorkbenchWindowActionDelegate {

	/** The initial <code>IWorkbenchWindow</code>. */
	private IWorkbenchWindow window;

	/**
	 * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
	 */
	public void run(IAction action) {
		final UnzipTitleAreaDialog dialog = new UnzipTitleAreaDialog(window
				.getShell());
		if (dialog.open() == IStatus.OK) {
			UnzipJob job = new UnzipJob(dialog.getZipFile(), dialog
					.getTargetDirectory());
			job.addJobChangeListener(new JobChangeAdapter() {
				/**
				 * @see org.eclipse.core.runtime.jobs.JobChangeAdapter#done(org.eclipse.core.runtime.jobs.IJobChangeEvent)
				 */
				public void done(final IJobChangeEvent event) {
					window.getShell().getDisplay().asyncExec(new Runnable() {
						/**
						 * @see java.lang.Runnable#run()
						 */
						public void run() {
							if (event.getResult().isOK()) {
								MessageDialog.openInformation(
										window.getShell(), "ZIP Manager",
										"Unzipping file "
												+ dialog.getZipFile().getName()
												+ " successfully completed.");
							}
							else {
								MessageDialog.openError(window.getShell(),
										"ZIP Manager", "Unzipping file "
												+ dialog.getZipFile().getName()
												+ " not completed.");
							}
						}
					});
				}
			});
			job.schedule();
		}
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(org.eclipse.jface.action.IAction,
	 *      org.eclipse.jface.viewers.ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}

	/**
	 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#dispose()
	 */
	public void dispose() {

	}

	/**
	 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#init(org.eclipse.ui.IWorkbenchWindow)
	 */
	public void init(IWorkbenchWindow window) {
		this.window = window;
	}

}
