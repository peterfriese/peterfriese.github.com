/*
 * UnzipDialogComposite.java created on 15.06.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */
package de.nordakademie.zipmanager.ui.dialog;

import java.io.File;
import java.util.Collections;
import java.util.zip.ZipFile;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Text;

/**
 * @author Stefan Reichert
 */
public class UnzipDialogComposite extends Composite {

	/** Widget. */
	private Text textZipFile;

	/** Widget. */
	private Button buttonChooseZipFile;

	/** Widget. */
	private ListViewer listViewerZipFileEntries;

	/** Widget. */
	private Text textTargetDirectory;

	/** The selected ZIP file. */
	private ZipFile zipFile;

	/** The target directory. */
	private File targetDirectory;

	/** Widget. */
	private Button buttonChooseTargetDirectory;

	/**
	 * Constructor for UnzipDialogComposite.
	 * 
	 * @param parent
	 *        The parent <code>Composite</code>
	 * @param style
	 *        The style bits
	 */
	public UnzipDialogComposite(Composite parent, int style) {
		super(parent, style);
		initialize();
	}

	/**
	 * Initializes this <code>Composite</code>.
	 */
	private void initialize() {
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 3;
		gridLayout.verticalSpacing = 2;
		gridLayout.marginWidth = 5;
		gridLayout.marginHeight = 5;
		gridLayout.horizontalSpacing = 2;
		this.setLayout(gridLayout);

		Label labelZipFile = new Label(this, SWT.NONE);
		labelZipFile.setText("Chosen ZIP file:");
		GridData gridDataLabelZipFile = new GridData();
		gridDataLabelZipFile.horizontalAlignment = GridData.FILL;
		gridDataLabelZipFile.horizontalIndent = 5;
		gridDataLabelZipFile.verticalAlignment = GridData.CENTER;
		labelZipFile.setLayoutData(gridDataLabelZipFile);

		textZipFile = new Text(this, SWT.BORDER);
		textZipFile.setEnabled(false);
		textZipFile.setBackground(getShell().getDisplay().getSystemColor(
				SWT.COLOR_WHITE));
		GridData gridDataTextZipFile = new GridData();
		gridDataTextZipFile.horizontalAlignment = GridData.FILL;
		gridDataTextZipFile.grabExcessHorizontalSpace = true;
		gridDataTextZipFile.heightHint = -1;
		gridDataTextZipFile.widthHint = 350;
		gridDataTextZipFile.verticalAlignment = GridData.CENTER;

		textZipFile.setLayoutData(gridDataTextZipFile);
		textZipFile.addModifyListener(new ModifyListener() {
			/**
			 * @see org.eclipse.swt.events.ModifyListener#modifyText(org.eclipse.swt.events.ModifyEvent)
			 */
			public void modifyText(ModifyEvent event) {
				File file = new File(textZipFile.getText());
				if (file.exists() && file.isFile()) {
					try {
						zipFile = new ZipFile(file);
						listViewerZipFileEntries.setInput(Collections
								.list(zipFile.entries()));
					}
					catch (Exception exception) {
						exception.printStackTrace();
					}
				}
				else {
					zipFile = null;
				}
			}
		});

		buttonChooseZipFile = new Button(this, SWT.NONE);
		buttonChooseZipFile.setText("Choose ZIP file...");
		GridData gridDataButtonChooseZipFile = new GridData();
		gridDataButtonChooseZipFile.horizontalAlignment = GridData.FILL;
		gridDataButtonChooseZipFile.verticalAlignment = GridData.CENTER;

		buttonChooseZipFile.setLayoutData(gridDataButtonChooseZipFile);
		buttonChooseZipFile.addSelectionListener(new SelectionAdapter() {
			/**
			 * @see org.eclipse.swt.events.SelectionListener#widgetSelected(org.eclipse.swt.events.SelectionEvent)
			 */
			public void widgetSelected(SelectionEvent event) {
				FileDialog fileDialog = new FileDialog(getShell());
				fileDialog.setText("Choose a ZIP file...");
				fileDialog.setFilterExtensions(new String[] { "*.zip" });
				fileDialog.setFilterNames(new String[] { "All ZIP files" });
				String fileString = fileDialog.open();
				if (fileString == null) {
					textZipFile.setText(new String());
				}
				else {
					textZipFile.setText(fileString);
				}
			}
		});
		List listZipFileEntries = new List(this, SWT.BORDER | SWT.V_SCROLL);
		GridData gridDataListZipFileEntries = new GridData();
		gridDataListZipFileEntries.horizontalAlignment = GridData.FILL;
		gridDataListZipFileEntries.horizontalSpan = 3;
		gridDataListZipFileEntries.grabExcessHorizontalSpace = true;
		gridDataListZipFileEntries.heightHint = 200;
		gridDataListZipFileEntries.verticalAlignment = GridData.CENTER;
		listZipFileEntries.setLayoutData(gridDataListZipFileEntries);

		listViewerZipFileEntries = new ListViewer(listZipFileEntries);
		listViewerZipFileEntries.setContentProvider(new ArrayContentProvider());
		Label labelTargetDirectory = new Label(this, SWT.NONE);

		labelTargetDirectory.setText("Chosen target directory:");
		GridData gridDataLabelTargetDirectory = new GridData();
		gridDataLabelTargetDirectory.horizontalAlignment = GridData.FILL;
		gridDataLabelTargetDirectory.horizontalIndent = 10;
		gridDataLabelTargetDirectory.verticalAlignment = GridData.CENTER;
		labelTargetDirectory.setLayoutData(gridDataLabelTargetDirectory);

		textTargetDirectory = new Text(this, SWT.BORDER);
		textTargetDirectory.setEnabled(false);
		textTargetDirectory.setBackground(getShell().getDisplay()
				.getSystemColor(SWT.COLOR_WHITE));
		GridData gridDatatextTargetDirectory = new GridData();
		gridDatatextTargetDirectory.horizontalAlignment = GridData.FILL;
		gridDatatextTargetDirectory.grabExcessHorizontalSpace = true;
		gridDatatextTargetDirectory.widthHint = 350;
		gridDatatextTargetDirectory.verticalAlignment = GridData.CENTER;

		textTargetDirectory.setLayoutData(gridDatatextTargetDirectory);
		textTargetDirectory.addModifyListener(new ModifyListener() {
			/**
			 * @see org.eclipse.swt.events.ModifyListener#modifyText(org.eclipse.swt.events.ModifyEvent)
			 */
			public void modifyText(ModifyEvent event) {
				File file = new File(textTargetDirectory.getText());
				if (file.exists() && file.isDirectory()) {
					targetDirectory = file;
				}
				else {
					targetDirectory = null;
				}
			}
		});
		buttonChooseTargetDirectory = new Button(this, SWT.NONE);
		buttonChooseTargetDirectory.setText("Choose target directory...");
		buttonChooseTargetDirectory.setLayoutData(gridDataLabelZipFile);
		buttonChooseTargetDirectory
				.addSelectionListener(new SelectionAdapter() {
					/**
					 * @see org.eclipse.swt.events.ChooseionListener#widgetChooseed(org.eclipse.swt.events.ChooseionEvent)
					 */
					public void widgetSelected(SelectionEvent event) {
						DirectoryDialog directoryDialog = new DirectoryDialog(
								getShell());
						directoryDialog.setText("Choose target directory...");
						String targetDirectoryString = directoryDialog.open();
						if (targetDirectoryString == null) {
							textTargetDirectory.setText(new String());
						}
						else {
							textTargetDirectory.setText(targetDirectoryString);
						}
					}
				});
		this.setSize(new Point(600, 400));
	}

	/**
	 * @return the target directory
	 */
	public File getTargetDirectory() {
		return targetDirectory;
	}

	/**
	 * @return the selected <i>ZIP file</i>
	 */
	public ZipFile getZipFile() {
		return zipFile;
	}
}
