/*
 * UnzipSchedulingRule.java created on 25.07.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */

package de.nordakademie.zipmanager.ui.job;

import java.util.zip.ZipFile;

import org.eclipse.core.runtime.jobs.ISchedulingRule;

/**
 * @author Stefan Reichert
 */
public class UnzipSchedulingRule implements ISchedulingRule {

	/** The <code>ZipFile</code> which is to be unzipped. */
	private ZipFile zipFile;

	/**
	 * Constructor for UnzipSchedulingRule.
	 * 
	 * @param zipFile
	 *        The <code>ZipFile</code> which is to be unzipped
	 */
	public UnzipSchedulingRule(ZipFile zipFile) {
		super();
		this.zipFile = zipFile;
	}

	/**
	 * @see org.eclipse.core.runtime.jobs.ISchedulingRule#contains(org.eclipse.core.runtime.jobs.ISchedulingRule)
	 */
	public boolean contains(ISchedulingRule rule) {
		if (rule instanceof UnzipSchedulingRule) {
			UnzipSchedulingRule unzipSchedulingRule = (UnzipSchedulingRule) rule;
			return unzipSchedulingRule.getZipFile().getName().equalsIgnoreCase(
					zipFile.getName());
		}
		return false;
	}

	/**
	 * @see org.eclipse.core.runtime.jobs.ISchedulingRule#isConflicting(org.eclipse.core.runtime.jobs.ISchedulingRule)
	 */
	public boolean isConflicting(ISchedulingRule rule) {
		if (rule instanceof UnzipSchedulingRule) {
			UnzipSchedulingRule unzipSchedulingRule = (UnzipSchedulingRule) rule;
			return unzipSchedulingRule.getZipFile().getName().equalsIgnoreCase(
					zipFile.getName());
		}
		return false;
	}

	/**
	 * @return the <code>ZipFile</code> which is to be unzipped
	 */
	public ZipFile getZipFile() {
		return zipFile;
	}

}
