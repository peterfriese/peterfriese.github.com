/*
 * UnzipJob.java created on 15.06.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */
package de.nordakademie.zipmanager.ui.job;

import java.io.File;
import java.util.Collections;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;

import de.nordakademie.zipmanager.core.ZipManager;
import de.nordakademie.zipmanager.core.listener.IZipManagerListener;

/**
 * @author Stefan Reichert
 */
public class UnzipJob extends Job {

	/** The <i>ZIP file</i> to be unziped. */
	private final ZipFile zipFile;

	/** The target directory. */
	private File targetDirectory;

	/**
	 * Constructor for UnzipJob.
	 * 
	 * @param zipFile
	 *        The <i>ZIP file</i> to be unziped
	 * @param targetDirectory
	 *        The target directory
	 */
	public UnzipJob(ZipFile zipFile, File targetDirectory) {
		super("Unzip file " + zipFile.getName());
		setUser(true);
		setRule(new UnzipSchedulingRule(zipFile));
		this.zipFile = zipFile;
		this.targetDirectory = targetDirectory;
	}

	/**
	 * @see org.eclipse.core.runtime.jobs.Job#run(org.eclipse.core.runtime.IProgressMonitor)
	 */
	protected IStatus run(IProgressMonitor monitor) {
		ZipManager zipManager = new ZipManager(zipFile);
		zipManager.addListener(new ZipManagerListener(monitor));
		monitor.beginTask("Unzipping", Collections.list(zipFile.entries())
				.size());
		zipManager.unzip(targetDirectory);
		monitor.done();
		return Status.OK_STATUS;
	}

	/**
	 * A <code>IZipManagerListener</code> that updates the given
	 * <code>IProgressMonitor</code>.
	 */
	private class ZipManagerListener implements IZipManagerListener {

		/** The <code>IProgressMonitor</code> to update. */
		private IProgressMonitor monitor;

		/**
		 * Constructor for ZipManagerListener.
		 * 
		 * @param monitor
		 *        The <code>IProgressMonitor</code> to update
		 */
		public ZipManagerListener(IProgressMonitor monitor) {
			super();
			this.monitor = monitor;
		}

		/**
		 * @see de.nordakademie.zipmanager.core.listener.IZipManagerListener#extractionAborted(java.util.zip.ZipEntry,
		 *      java.lang.Throwable)
		 */
		public void extractionAborted(ZipEntry entry, Throwable throwable) {
			// Do nothing
		}

		/**
		 * @see de.nordakademie.zipmanager.core.listener.IZipManagerListener#extractionFinished(java.util.zip.ZipEntry)
		 */
		public void extractionFinished(ZipEntry entry) {
			// Do nothing
		}

		/**
		 * @see de.nordakademie.zipmanager.core.listener.IZipManagerListener#extractionStarted(java.util.zip.ZipEntry)
		 */
		public void extractionStarted(ZipEntry entry) {
			monitor.subTask(targetDirectory.getAbsolutePath() + File.separator
					+ entry.getName().replace('/', File.separatorChar));
			monitor.worked(1);
		}
	}
}
