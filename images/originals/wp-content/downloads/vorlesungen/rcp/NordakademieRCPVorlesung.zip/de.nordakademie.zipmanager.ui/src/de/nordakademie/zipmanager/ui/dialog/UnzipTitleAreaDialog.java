/*
 * UnzipTitleAreaDialog.java created on 15.06.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */
package de.nordakademie.zipmanager.ui.dialog;

import java.io.File;
import java.util.zip.ZipFile;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Stefan Reichert
 */
public class UnzipTitleAreaDialog extends TitleAreaDialog {

	/** Widget. */
	private UnzipDialogComposite unzipDialogComposite;

	/**
	 * Constructor for UnzipTitleAreaDialog
	 * 
	 * @param parentShell
	 *        The parent <code>Shell</code>
	 */
	public UnzipTitleAreaDialog(Shell parentShell) {
		super(parentShell);
	}

	/**
	 * @see org.eclipse.jface.window.Window#configureShell(org.eclipse.swt.widgets.Shell)
	 */
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		setHelpAvailable(false);
		newShell.setText("Unzip a ZIP file...");
	}

	/**
	 * @see org.eclipse.jface.dialogs.Dialog#createDialogArea(org.eclipse.swt.widgets.Composite)
	 */
	protected Control createDialogArea(Composite parent) {
		Composite area = (Composite) super.createDialogArea(parent);
		unzipDialogComposite = new UnzipDialogComposite(area, SWT.NONE);
		unzipDialogComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL,
				true, false));

		setTitle("Unzip a ZIP file");
		setMessage("Please select a ZIP file and a target directory.");
		return area;
	}

	/**
	 * @return the target directory
	 */
	public File getTargetDirectory() {
		return unzipDialogComposite.getTargetDirectory();
	}

	/**
	 * @return the selected <i>ZIP file</i>
	 */
	public ZipFile getZipFile() {
		return unzipDialogComposite.getZipFile();
	}

	/**
	 * @see org.eclipse.jface.window.Window#getInitialSize()
	 */
	protected Point getInitialSize() {
		return new Point(700, 400);
	}

	/**
	 * @see org.eclipse.jface.dialogs.Dialog#okPressed()b
	 */
	protected void okPressed() {
		ZipFile zipFile = unzipDialogComposite.getZipFile();
		File targetDirectory = unzipDialogComposite.getTargetDirectory();
		if (zipFile != null && targetDirectory != null) {
			super.okPressed();
		}
	}

	/**
	 * @see org.eclipse.jface.dialogs.Dialog#createButtonsForButtonBar(org.eclipse.swt.widgets.Composite)
	 */
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, "Unzip", true);
		createButton(parent, IDialogConstants.CANCEL_ID,
				IDialogConstants.CANCEL_LABEL, false);
	}
}
