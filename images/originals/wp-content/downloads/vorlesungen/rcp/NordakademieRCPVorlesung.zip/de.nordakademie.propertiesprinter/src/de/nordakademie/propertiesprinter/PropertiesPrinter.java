/*
 * Activator.java created on 26.07.2006
 * 
 * Copyright (c) 2006 Peter Friese and Stefan Reichert
 * All rights reserved. 
 * 
 * This program and the accompanying materials are proprietary information 
 * of Peter Friese and Stefan Reichert.
 * Use is subject to license terms.
 */

package de.nordakademie.propertiesprinter;

import java.util.Map.Entry;

import org.apache.commons.collections.Closure;
import org.apache.commons.collections.CollectionUtils;
import org.eclipse.ui.IStartup;

/**
 * @author Stefan Reichert
 */
public class PropertiesPrinter implements IStartup {

	/**
	 * @see org.eclipse.ui.IStartup#earlyStartup()
	 */
	public void earlyStartup() {
		System.out.println("--------------------------------------------------");
		System.out.println("System properties");
		CollectionUtils.forAllDo(System.getProperties().entrySet(),
				new Closure() {
					/**
					 * @see org.apache.commons.collections.Closure#execute(java.lang.Object)
					 */
					public void execute(Object object) {
						Entry entry = (Entry) object;
						System.out.print(entry.getKey());
						System.out.print(" = ");
						System.out.println(entry.getValue());
					}
				});
		System.out.println("--------------------------------------------------");
	}
}
